-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 05, 2024 at 12:48 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `central`
--

-- --------------------------------------------------------

--
-- Table structure for table `districts`
--

CREATE TABLE `districts` (
  `district_id` int(11) NOT NULL,
  `district_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `districts`
--

INSERT INTO `districts` (`district_id`, `district_name`) VALUES
(1, 'krishnarayapuram'),
(2, 'karur');

-- --------------------------------------------------------

--
-- Table structure for table `milkcollection`
--

CREATE TABLE `milkcollection` (
  `collection_id` int(11) NOT NULL,
  `society_id` int(11) NOT NULL,
  `collection_date` date NOT NULL,
  `collection_time` time NOT NULL,
  `shift` enum('morning','evening','','') NOT NULL DEFAULT 'morning',
  `snf` decimal(5,2) NOT NULL,
  `fat` decimal(5,2) NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `provider_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `milkcollection`
--

INSERT INTO `milkcollection` (`collection_id`, `society_id`, `collection_date`, `collection_time`, `shift`, `snf`, `fat`, `quantity`, `provider_id`) VALUES
(1, 123, '2024-03-25', '08:00:00', 'morning', 3.85, 3.20, 150.50, 456),
(7, 13, '2024-04-01', '09:00:12', 'morning', 3.10, 3.00, 45.00, 8),
(8, 13, '2024-04-02', '07:40:12', 'morning', 3.00, 7.50, 39.00, 1),
(9, 12, '2024-04-02', '08:50:13', 'morning', 4.10, 6.00, 42.00, 1),
(10, 12, '2024-04-03', '06:00:13', 'morning', 4.60, 4.00, 45.00, 2),
(11, 13, '2024-04-02', '08:50:13', 'morning', 3.10, 3.00, 65.00, 4),
(12, 12, '2024-04-03', '07:10:14', 'morning', 4.10, 4.00, 38.00, 6),
(13, 13, '2024-04-03', '07:00:00', 'morning', 3.10, 3.00, 46.00, 3),
(14, 12, '2024-04-03', '10:00:14', 'morning', 2.10, 2.00, 40.00, 2),
(15, 13, '2024-04-02', '08:50:14', 'morning', 2.80, 2.00, 29.00, 7),
(16, 12, '2024-04-02', '09:00:15', 'morning', 3.60, 7.00, 30.00, 3),
(17, 13, '2024-04-02', '08:10:15', 'morning', 3.50, 3.00, 42.00, 9),
(18, 12, '2024-04-01', '00:00:15', 'morning', 3.60, 7.00, 62.00, 1),
(19, 13, '2024-04-01', '09:10:15', 'morning', 3.90, 3.00, 55.00, 7),
(20, 12, '2024-04-01', '08:50:15', 'morning', 4.00, 3.50, 40.50, 4),
(21, 13, '2024-03-31', '08:45:16', 'morning', 4.20, 4.00, 69.70, 3),
(22, 12, '2024-04-01', '08:40:16', 'morning', 4.20, 4.00, 39.80, 8),
(23, 13, '2024-04-02', '09:00:16', 'morning', 4.40, 4.00, 43.60, 1),
(24, 12, '2024-04-02', '08:40:17', 'morning', 4.70, 7.00, 35.00, 1),
(25, 12, '2024-04-03', '08:00:17', 'morning', 4.60, 4.00, 35.00, 1),
(26, 13, '2024-04-02', '11:00:17', 'morning', 4.70, 4.00, 34.00, 1),
(27, 13, '2024-04-03', '10:40:17', 'morning', 3.90, 7.00, 53.00, 1),
(28, 13, '2024-04-02', '10:30:18', 'morning', 3.50, 3.00, 34.00, 3),
(29, 12, '2024-04-02', '00:00:18', 'morning', 3.60, 3.00, 40.00, 1),
(30, 12, '2024-04-01', '10:00:20', 'morning', 3.30, 2.90, 43.00, 1),
(31, 13, '2024-04-04', '00:00:10', 'morning', 3.00, 6.00, 45.00, 456),
(33, 12, '2024-04-04', '09:23:56', 'morning', 3.50, 4.50, 44.00, 1),
(111, 1, '2024-04-03', '08:00:10', 'morning', 2.00, 6.00, 30.00, 1),
(112, 13, '2024-04-04', '15:27:41', 'morning', 4.20, 5.00, 45.00, 1),
(113, 13, '2024-04-04', '15:37:53', 'morning', 4.20, 5.00, 45.00, 1),
(114, 13, '2024-04-04', '15:40:46', 'evening', 4.50, 5.80, 32.00, 1),
(115, 13, '2024-04-04', '15:44:24', 'morning', 4.20, 5.80, 10.00, 2),
(116, 13, '2024-04-04', '15:45:01', 'morning', 4.50, 6.00, 40.00, 2),
(117, 13, '2024-04-04', '15:49:15', 'morning', 4.40, 6.10, 3.00, 3),
(118, 1, '2024-04-05', '10:29:43', 'morning', 3.40, 7.00, 32.00, 2),
(119, 1, '2024-04-05', '10:30:33', 'morning', 3.60, 4.60, 4.00, 3),
(120, 1, '2024-04-05', '13:45:09', 'evening', 6.40, 4.70, 1.00, 2);

-- --------------------------------------------------------

--
-- Table structure for table `providers`
--

CREATE TABLE `providers` (
  `provider_id` int(11) NOT NULL,
  `provider_name` varchar(255) DEFAULT NULL,
  `phone_no` bigint(10) NOT NULL,
  `contact_info` varchar(255) DEFAULT NULL,
  `society_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `providers`
--

INSERT INTO `providers` (`provider_id`, `provider_name`, `phone_no`, `contact_info`, `society_name`) VALUES
(1, 'gokul', 8778964757, '525 gm karur', ''),
(2, 'rahul', 9898734867, 'abcd', ''),
(3, 'giri', 9809765456, 'qwer', ''),
(4, 'mathan', 0, 'sdfg', ''),
(5, 'karthi', 0, 'mnbcvcv', ''),
(6, 'pranav', 0, 'cjghh', ''),
(7, 'nirmal', 0, 'fchg', ''),
(8, 'aravindh', 0, 'rcfrwv', ''),
(9, 'muthu', 0, 'sfebeb', ''),
(10, 'sibi', 9564123585, 'hgbgskjgvbi', '1'),
(33, 'karthisan', 9875236541, 'asdfg', '2'),
(456, 'kavin', 0, 'ggchg', '');

-- --------------------------------------------------------

--
-- Table structure for table `societies`
--

CREATE TABLE `societies` (
  `society_id` int(11) NOT NULL,
  `society_name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `union_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `societies`
--

INSERT INTO `societies` (`society_id`, `society_name`, `password`, `union_id`) VALUES
(1, 'aavin01', '1234', 1),
(2, 'vka', '1234', 1),
(4, 'aavin5', '3456', 2),
(12, 'aavin02', 'karur', 1),
(13, 'aavin03', 'karur', 45),
(123, 'aavin04', '1234', 45);

-- --------------------------------------------------------

--
-- Table structure for table `tablename`
--

CREATE TABLE `tablename` (
  `collection_id` int(11) DEFAULT NULL,
  `society_id` int(11) DEFAULT NULL,
  `collection_date` varchar(512) DEFAULT NULL,
  `collection_time` varchar(512) DEFAULT NULL,
  `shf` double DEFAULT NULL,
  `fat` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `provider_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tablename`
--

INSERT INTO `tablename` (`collection_id`, `society_id`, `collection_date`, `collection_time`, `shf`, `fat`, `quantity`, `provider_id`) VALUES
(0, 0, '', '', 0, 0, 0, 0),
(1, 12, '31-03-2024', '08.00.00', 3.85, 3, 121, 145),
(2, 12, '31-03-2024', '09.00.00', 4, 4, 111, 146),
(3, 13, '31-03-2024', '10.00.00', 4.2, 4, 120, 147),
(4, 12, '31-03-2024', '12.00.00', 4.1, 4, 134, 148),
(5, 12, '31-03-2024', '12.30.00', 3.2, 3, 123, 149),
(6, 13, '31-03-2024', '12.35.00', 3.3, 3, 134, 150),
(7, 13, '31-03-2024', '12.40.00', 3.1, 3, 145, 151),
(8, 13, '31-03-2024', '12.45.00', 3, 3, 123, 152),
(9, 12, '31-03-2024', '13.00.00', 4.1, 4, 142, 153),
(10, 12, '31-03-2024', '13.30.00', 4.6, 4, 145, 154),
(11, 13, '31-03-2024', '13.45.00', 3.1, 3, 165, 155),
(12, 12, '31-03-2024', '14.00.00', 4.1, 4, 138, 156),
(13, 13, '31-03-2024', '14.15.00', 3.1, 3, 146, 157),
(14, 12, '31-03-2024', '14.30.00', 2.1, 2, 190, 158),
(15, 13, '31-03-2024', '14.45.00', 2.8, 2, 129, 159),
(16, 12, '31-03-2024', '15.00.00', 3.6, 3, 130, 160),
(17, 13, '31-03-2024', '15.14.00', 3.5, 3, 142, 161),
(18, 12, '31-03-2024', '15.30.00', 3.6, 3, 183, 162),
(19, 13, '31-03-2024', '15.45.00', 3.9, 3, 125, 163),
(20, 12, '31-03-2024', '15.55.00', 4, 4, 121, 164),
(21, 13, '31-03-2024', '16.00.00', 4.2, 4, 128, 165),
(22, 12, '31-03-2024', '16.30.00', 4.2, 4, 131, 166),
(23, 13, '31-03-2024', '16.37.00', 4.4, 4, 144, 167),
(24, 12, '31-03-2024', '17.00.00', 4.7, 4, 135, 168),
(25, 12, '31-03-2024', '17.30.00', 4.6, 4, 134, 169),
(26, 13, '31-03-2024', '17.45.00', 4.7, 4, 134, 170),
(27, 13, '31-03-2024', '17.55.00', 3.9, 4, 153, 171),
(28, 13, '31-03-2024', '18.00.00', 3.5, 3, 134, 172),
(29, 12, '31-03-2024', '18.30.00', 3.6, 3, 164, 173),
(30, 12, '31-03-2024', '20.00.00', 3.3, 3, 143, 174),
(0, 0, '', '', 0, 0, 0, 0),
(1, 12, '31-03-2024', '08.00.00', 3.85, 3, 121, 145),
(2, 12, '31-03-2024', '09.00.00', 4, 4, 111, 146),
(3, 13, '31-03-2024', '10.00.00', 4.2, 4, 120, 147),
(4, 12, '31-03-2024', '12.00.00', 4.1, 4, 134, 148),
(5, 12, '31-03-2024', '12.30.00', 3.2, 3, 123, 149),
(6, 13, '31-03-2024', '12.35.00', 3.3, 3, 134, 150),
(7, 13, '31-03-2024', '12.40.00', 3.1, 3, 145, 151),
(8, 13, '31-03-2024', '12.45.00', 3, 3, 123, 152),
(9, 12, '31-03-2024', '13.00.00', 4.1, 4, 142, 153),
(10, 12, '31-03-2024', '13.30.00', 4.6, 4, 145, 154),
(11, 13, '31-03-2024', '13.45.00', 3.1, 3, 165, 155),
(12, 12, '31-03-2024', '14.00.00', 4.1, 4, 138, 156),
(13, 13, '31-03-2024', '14.15.00', 3.1, 3, 146, 157),
(14, 12, '31-03-2024', '14.30.00', 2.1, 2, 190, 158),
(15, 13, '31-03-2024', '14.45.00', 2.8, 2, 129, 159),
(16, 12, '31-03-2024', '15.00.00', 3.6, 3, 130, 160),
(17, 13, '31-03-2024', '15.14.00', 3.5, 3, 142, 161),
(18, 12, '31-03-2024', '15.30.00', 3.6, 3, 183, 162),
(19, 13, '31-03-2024', '15.45.00', 3.9, 3, 125, 163),
(20, 12, '31-03-2024', '15.55.00', 4, 4, 121, 164),
(21, 13, '31-03-2024', '16.00.00', 4.2, 4, 128, 165),
(22, 12, '31-03-2024', '16.30.00', 4.2, 4, 131, 166),
(23, 13, '31-03-2024', '16.37.00', 4.4, 4, 144, 167),
(24, 12, '31-03-2024', '17.00.00', 4.7, 4, 135, 168),
(25, 12, '31-03-2024', '17.30.00', 4.6, 4, 134, 169),
(26, 13, '31-03-2024', '17.45.00', 4.7, 4, 134, 170),
(27, 13, '31-03-2024', '17.55.00', 3.9, 4, 153, 171),
(28, 13, '31-03-2024', '18.00.00', 3.5, 3, 134, 172),
(29, 12, '31-03-2024', '18.30.00', 3.6, 3, 164, 173),
(30, 12, '31-03-2024', '20.00.00', 3.3, 3, 143, 174);

-- --------------------------------------------------------

--
-- Table structure for table `unions`
--

CREATE TABLE `unions` (
  `union_id` int(11) NOT NULL,
  `union_name` varchar(255) NOT NULL,
  `district_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `unions`
--

INSERT INTO `unions` (`union_id`, `union_name`, `district_id`) VALUES
(1, 'gandhigramam', 2),
(2, 'vengamedu', 2),
(3, 'puliyur', 1),
(45, ' Thanthoni', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `districts`
--
ALTER TABLE `districts`
  ADD PRIMARY KEY (`district_id`);

--
-- Indexes for table `milkcollection`
--
ALTER TABLE `milkcollection`
  ADD PRIMARY KEY (`collection_id`),
  ADD KEY `society_id` (`society_id`),
  ADD KEY `provider_id` (`provider_id`);

--
-- Indexes for table `providers`
--
ALTER TABLE `providers`
  ADD PRIMARY KEY (`provider_id`);

--
-- Indexes for table `societies`
--
ALTER TABLE `societies`
  ADD PRIMARY KEY (`society_id`),
  ADD KEY `union_id` (`union_id`);

--
-- Indexes for table `unions`
--
ALTER TABLE `unions`
  ADD PRIMARY KEY (`union_id`),
  ADD KEY `district_id` (`district_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `milkcollection`
--
ALTER TABLE `milkcollection`
  MODIFY `collection_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=121;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `milkcollection`
--
ALTER TABLE `milkcollection`
  ADD CONSTRAINT `milkcollection_ibfk_1` FOREIGN KEY (`society_id`) REFERENCES `societies` (`society_id`),
  ADD CONSTRAINT `milkcollection_ibfk_2` FOREIGN KEY (`provider_id`) REFERENCES `providers` (`provider_id`);

--
-- Constraints for table `societies`
--
ALTER TABLE `societies`
  ADD CONSTRAINT `societies_ibfk_1` FOREIGN KEY (`union_id`) REFERENCES `unions` (`union_id`);

--
-- Constraints for table `unions`
--
ALTER TABLE `unions`
  ADD CONSTRAINT `unions_ibfk_1` FOREIGN KEY (`district_id`) REFERENCES `districts` (`district_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
