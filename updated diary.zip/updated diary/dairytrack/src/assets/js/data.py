import json
from django.http import HttpResponse
from django.shortcuts import render
from django.template import loader
 
def index(request):
    datapoints = [
        { "label": "Online Store",  "y": 27  },
        { "label": "Offline Store", "y": 25  },        
        { "label": "Discounted Sale",  "y": 30  },
        { "label": "B2B Channel", "y": 8  },
        { "label": "Others",  "y": 10  }
    ]
    datapoints_json = json.dumps(datapoints)
    return render(request, 'dashboard.js', { "datapoints" : datapoints_json })