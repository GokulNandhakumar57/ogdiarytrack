<?php
session_start();

try {
    include 'connect.php';
    if ($_SERVER["REQUEST_METHOD"] == "POST"){
    // Get username and password from the form submission
    $username = $_POST['username'];
    $pass = $_POST['password'];

    // Check for admin login
    if ($username == "admin"){
 	if($pass == "pass") {
        // Admin login successful
        $_SESSION['logged_in'] = true;
        $_SESSION['user_type'] = 'admin';
        // Redirect to dashboard.php
        header("Location: dashboard.php");
        exit();
        }
	else{
		echo "<script> alert('Invalid Admin Password...'); </script>";
	}
    } else {
        // Check for society login
        $sql = "SELECT * FROM societies WHERE society_name = :username AND password= :pass"; // Changed society_name to username and added password field
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':username', $username);
        $stmt->bindParam(':pass', $pass);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($stmt->rowCount() > 0) {
            // Society login successful
            $_SESSION['logged_in'] = true;
            $_SESSION['user_type'] = 'society';
            $_SESSION['society_id'] = $row['society_id'];
            $_SESSION['union_id'] = $row['union_id'];

            // Get district based on union_id
            $sql = "SELECT district_id FROM unions WHERE union_id = :union_id";
            $district_stmt = $conn->prepare($sql);
            $district_stmt->bindParam(':union_id', $row['union_id']);
            $district_stmt->execute();
            $district_row = $district_stmt->fetch(PDO::FETCH_ASSOC);
            $_SESSION['district'] = $district_row['district_id'];

            // Redirect to dataentry.php
            header("Location: dataentry.php");
            exit();
        } else {
            // Authentication failed
            $_SESSION['logged_in'] = false;
            echo "<script> alert('Login failed...'); </script>";
	    echo "<script>window.location.href ='index.php'</script>";
            exit();
        }
    }
}
} catch (Exception $e) {
    // Handle exceptions gracefully (log error or show a generic error message)
    echo $e->getMessage();
}
?>
<script>
    function showError(message){
	let errorMessage=document.createElement('div');
	errorMessage.ClassName='error';
	errorMessage.innerHTML=message;
	document.body.appendChild(errorMessage);

	setTimeout(() => {
            errorMessage.remove();
        }, 3000);
	}
	function showSuccess(message){
	let successMessage=document.createElement('div');
	errorMessage.ClassName='success';
	errorMessage.innerHTML=message;
	document.body.appendChild(successMessage);

	setTimeout(() => {
            errorMessage.remove();
        }, 3000);
	}
</script>