<?php
// Include the database connection file
include 'connect.php';

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $provider_id = $_POST['provider_id'];
    $name = $_POST['name'];
    $phone_no = $_POST['phone_no'];
    $contact_details = $_POST['contact_details'];
    $society_id = $_POST['society_id'];
    $sql1="SELECT * FROM providers WHERE provider_id=:provider_id";
    $stmt1 = $conn->prepare($sql1);
    $stmt1->bindParam(':provider_id', $provider_id);
    $stmt1->execute();
    $row = $stmt1->fetch(PDO::FETCH_ASSOC);
    if ($stmt1->rowCount() > 0){
        echo "<script> alert('UserId already in use...')</script>";
        echo "<script>window.location.href ='providermanage.php'</script>";
        exit();
    }
    else{
    $sql = "INSERT INTO providers (provider_id,provider_name, phone_no, contact_info, society_name) VALUES (:provider_id, :name, :phone_no, :contact_details, :society_id)";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':provider_id', $provider_id);
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':phone_no', $phone_no);
    $stmt->bindParam(':contact_details', $contact_details);
    $stmt->bindParam(':society_id', $society_id);

    // Execute the statement
    if ($stmt->execute()) {
        echo "<script> alert('Provider added successfully.')</script>";
        echo "<script>window.location.href ='providermanage.php'</script>";
    } else {
        echo "<script> alert('Error: Unable to add provider.')</script>";
        echo "<script>window.location.href ='providermanage.php'</script>";
    }
}
}
?>
