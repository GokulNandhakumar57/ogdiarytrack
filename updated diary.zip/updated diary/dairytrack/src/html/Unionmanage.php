<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Add New Union</title>
<link rel="stylesheet" href="../assets/css/dataentry.css"/>
</head>
<body>
  <h2>Add New Union</h2>
  <form method="POST" action="Addunion.php">
    <label for="union_id">Union ID:</label><br>
    <input type="text" id="union_id" name="union_id" required><br><br>
    
    <label for="union_name">Union Name:</label><br>
    <input type="text" id="union_name" name="union_name" required><br><br>
    
    <label for="district_id">Choose District:</label><br>
    <select name="district_id" id="district_id" required>
      <option value="">Select District</option>
      <!-- PHP code to fetch and display districts -->
      <?php
        // Include the database connection file
        include 'connect.php';
        
        // Assuming $conn is the database connection
        $sql = "SELECT * FROM districts";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        if ($result) {
          foreach($result as $row) {
            echo "<option value='" . $row['district_id'] . "'>" . $row['district_name'] . "</option>";
          }
        }
      ?>
    </select><br><br>

    <input type="submit" value="Submit">
  </form>
</body>
</html>
