document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent default form submission

    // Normally, you would send the form data to the server for authentication here
    // For this example, let's assume successful login if both fields are filled
    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;

    if (username && password) {
        // If login successful, hide the login form and display the main content
        document.querySelector('.login-container').style.display = 'none';
        // Here you can display the main content of your page
    } else {
        alert('Please enter both username and password.');
    }
});
