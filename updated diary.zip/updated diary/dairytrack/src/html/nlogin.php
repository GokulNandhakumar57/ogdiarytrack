<?php
session_start();

try {
    include 'connect.php';
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Get username and password from the form submission
        $username = $_POST['username'];
        $pass = $_POST['password'];

        // Check for admin login
        if ($username == "admin") {
            if ($pass == "pass") {
                // Admin login successful
                $_SESSION['logged_in'] = true;
                $_SESSION['user_type'] = 'admin';
                // Set session success message
                $_SESSION['login_success'] = "Login Successful! Redirecting...";
                // Redirect to dashboard.php after displaying the message
                header("Location: dashboard.php");
                exit();
            } else {
                echo "<script> showError('Invalid Admin Password...'); </script>";
            }
        } else {
            // Check for society login
            $sql = "SELECT * FROM societies WHERE society_name = :username AND password= :pass"; // Changed society_name to username and added password field
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':username', $username);
            $stmt->bindParam(':pass', $pass);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($stmt->rowCount() > 0) {
                // Society login successful
                $_SESSION['logged_in'] = true;
                $_SESSION['user_type'] = 'society';
                $_SESSION['society_id'] = $row['society_id'];
                $_SESSION['union_id'] = $row['union_id'];

                // Get district based on union_id
                $sql = "SELECT district_id FROM unions WHERE union_id = :union_id";
                $district_stmt = $conn->prepare($sql);
                $district_stmt->bindParam(':union_id', $row['union_id']);
                $district_stmt->execute();
                $district_row = $district_stmt->fetch(PDO::FETCH_ASSOC);
                $_SESSION['district'] = $district_row['district_id'];

                // Set session success message
                $_SESSION['login_success'] = "Login Successful! Redirecting...";

                // Redirect to dataentry.php after displaying the message
                header("Location: dataentry.php");
                exit();
            } else {
                // Authentication failed
                $_SESSION['logged_in'] = false;
                echo "<script> showError('Login failed...'); </script>";
            }
        }
    }
} catch (Exception $e) {
    // Handle exceptions gracefully (log error or show a generic error message)
    echo $e->getMessage();
}
?>

<!-- JavaScript for Showing Messages and Redirection -->
<script>
    function showError(message) {
        // Show error message without redirecting
        let errorMessage = document.createElement('div');
        errorMessage.className = 'error';
        errorMessage.innerHTML = message;
        document.body.appendChild(errorMessage);

        // Optional: auto-hide after 3 seconds
        setTimeout(() => {
            errorMessage.remove();
        }, 3000);
    }

    function showSuccess(message) {
        // Show success message and redirect after 3 seconds
        let successMessage = document.createElement('div');
        successMessage.className = 'success';
        successMessage.innerHTML = message;
        document.body.appendChild(successMessage);

        // Redirect after 3 seconds
        setTimeout(() => {
            successMessage.remove();
            window.location.href = 'dashboard.php';  // Redirect to the desired page
        }, 3000);
    }

    <?php if (isset($_SESSION['login_success'])): ?>
        showSuccess('<?php echo $_SESSION['login_success']; ?>');
        <?php unset($_SESSION['login_success']); ?>  // Remove the session message after displaying it
    <?php endif; ?>
</script>

<style>
    .success, .error {
        padding: 10px;
        margin-top: 20px;
        font-size: 18px;
        border-radius: 5px;
        text-align: center;
    }

    .success {
        background-color: #4CAF50;
        color: white;
    }

    .error {
        background-color: #f44336;
        color: white;
    }
</style>
