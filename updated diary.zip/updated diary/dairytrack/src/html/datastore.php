<?php
session_start();
// Set no cache headers
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

// Check if user is logged in and has appropriate session data
if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] && isset($_SESSION['user_type']) && $_SESSION['user_type'] === 'society') {

  // Include database connection details
  require_once("connect.php"); // Replace with your actual connection file path

  $shift=$_POST['shift'];
  $provider_id = $_POST['provider_id'];
  $snf_value = $_POST['snf_value'];
  $fat = $_POST['fat'];
  $quantity = $_POST['quantity'];
  $society_id = $_SESSION['society_id']; 
  $todaydate=date("Y-m-d");

  $sql1="SELECT * FROM milkcollection where provider_id=:provider_id AND shift=:shift AND collection_date=:collection_date";
  $stmt1 = $conn->prepare($sql1);
  $stmt1->bindParam(':provider_id', $provider_id);
  $stmt1->bindParam(':shift', $shift);
  $stmt1->bindParam(':collection_date',$todaydate);
  $stmt1->execute();
  if($stmt1->rowCount()>0){
        echo "<script></script>";
  }
  $sql = "INSERT INTO milkcollection (society_id, provider_id, collection_date, collection_time,shift, snf, fat, quantity) 
          VALUES (:society_id, :provider_id, CURDATE(), CURTIME(),:shift, :snf_value, :fat, :quantity)";
  $stmt = $conn->prepare($sql);

  // Bind parameters to prevent SQL injection
  $stmt->bindParam(':society_id', $society_id);
  $stmt->bindParam(':provider_id', $provider_id);
  $stmt->bindParam(':shift', $shift);
  $stmt->bindParam(':snf_value', $snf_value);
  $stmt->bindParam(':fat', $fat);
  $stmt->bindParam(':quantity', $quantity);

  // Execute the query
  if ($stmt->execute()) {
    header("Location:dataentry.php");
  } else {
    echo "Error: " . $stmt->errorCode() . "<br>" . $stmt->errorInfo()[0];
  }
  $conn=null;

} else {
  // Redirect to login page if not logged in as society
  header("Location: login.php");
  exit();
}
?>
