<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Societies Milk Collection</title>
  <link rel="stylesheet" href="../assets/css/styles.min.css" />
  <style>
    /* CSS styling for the table */
    body{
      padding: 20px;
    }
    table {
      padding: 20px;
      width: 100%;
      border-collapse: collapse;
    }
    th, td {
      padding: 8px;
      text-align: left;
      border-bottom: 1px solid #ddd;
    }
    th {
      background-color: #f2f2f2;
    }
  </style>
</head>
<body>
  <h1 style="text-align:center;">Societies Milk Collection</h1>
  <table>
    <thead>
      <tr>
        <th>Society ID</th>
        <th>Society Name</th>
        <th>District Name</th>
        <th>Union Name</th>
      </tr>
    </thead>
    <tbody>
      <?php
        // Include database connection details
        include('connect.php');

        // Fetch data for each society along with district and union information
        $sql = "SELECT societies.society_id, societies.society_name, districts.district_name, unions.union_name
                FROM societies
                LEFT JOIN unions ON societies.union_id = unions.union_id
                LEFT JOIN districts ON unions.district_id = districts.district_id";

        $stmt = $conn->prepare($sql);
        $stmt->execute();

        // Display data for each society
        if ($stmt->rowCount() > 0) {
          while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            echo "<tr>";
            echo "<td>".$row['society_id']."</td>";
            echo "<td>".$row['society_name']."</td>";
            echo "<td>".$row['district_name']."</td>";
            echo "<td>".$row['union_name']."</td>";
            echo "</tr>";
          }
        } else {
          echo "<tr><td colspan='4'>No data found</td></tr>";
        }

        // Close connection
        $conn = null;
      ?>
    </tbody>
  </table>
</body>
</html>
