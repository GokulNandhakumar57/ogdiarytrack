<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Add New Provider</title>
<link rel="stylesheet" href="../assets/css/dataentry.css"/>
</head>
<body>
  <h2>Add New Provider</h2>
  <form method="POST" action="Addprovider.php">
    <label for="provider_id">Provider ID:</label><br>
    <input type="text" id="provider_id" name="provider_id" required><br><br>
    
    <label for="name">Name:</label><br>
    <input type="text" id="name" name="name" required><br><br>
    
    <label for="phone_no">Phone Number:</label><br>
    <input type="text" id="phone_no" name="phone_no" required><br><br>

    <label for="contact_details">Contact Details:</label><br>
    <textarea id="contact_details" name="contact_details" rows="4" cols="50" required></textarea><br><br>
    
    <label for="society_id">Choose Society:</label><br>
    <select name="society_id" id="society_id" required>
      <option value="">Select Society</option>
      <!-- PHP code to fetch and display societies -->
      <?php
        // Include the database connection file
        include 'connect.php';
        
        // Assuming $conn is the database connection
        $sql = "SELECT * FROM societies";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        if ($result) {
          foreach($result as $row) {
            echo "<option value='" . $row['society_id'] . "'>" . $row['society_name'] . "</option>";
          }
        }
      ?>
    </select><br><br>

    <input type="submit" value="Submit">
  </form>
</body>
</html>
