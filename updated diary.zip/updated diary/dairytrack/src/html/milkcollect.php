<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Milk Collection Page</title>
  <link rel="stylesheet" href="../assets/css/milkcollect.css"/>
</head>
<body>
  <div class="dateselect">
    <h1>Milk Collection Data</h1>
    <label for="collectionDate"><b>Choose a Collection Date:</b></label>
    <input type="date" id="collectionDate" name="collectionDate">
    <button onclick="filterData()">Filter</button>
    <button onclick="downloadCSV()">Download CSV</button> 
  </div>
  <table id="milkCollectionTable">
    <thead>
      <tr>
        <th>Collection ID</th>
        <th>Society ID</th>
        <th>Collection Date</th>
        <th>Collection Time</th>
        <th>Shift</th>
        <th>SNF</th>
        <th>Fat</th>
        <th>Quantity</th>
        <th>Provider ID</th>
      </tr>
    </thead>
    <tbody>
      <?php
        // Include database connection details
        include('connect.php');

        // Fetch data from milkcollection table
        $sql = "SELECT * FROM milkcollection";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        
        // Check if there are rows returned
        if ($stmt->rowCount() > 0) {
          // Output data rows
          while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            echo "<tr>";
            echo "<td>".$row['collection_id']."</td>";
            echo "<td>".$row['society_id']."</td>";
            echo "<td>".$row['collection_date']."</td>";
            echo "<td>".$row['collection_time']."</td>";
            echo "<td>".$row['shift']."</td>";
            echo "<td>".$row['snf']."</td>";
            echo "<td>".$row['fat']."</td>";
            echo "<td>".$row['quantity']."</td>";
            echo "<td>".$row['provider_id']."</td>";
            echo "</tr>";
          }
        } else {
          echo "<tr><td colspan='8'>No data found</td></tr>";
        }

        // Close connection
        $conn = null;
      ?>
    </tbody>
  </table>

  <script>
    function filterData() {
      var inputDate = document.getElementById("collectionDate").value;
      var rows = document.getElementById("milkCollectionTable").getElementsByTagName("tbody")[0].getElementsByTagName("tr");
      var hasData = false;
      for (var i = 0; i < rows.length; i++) {
        var rowDate = rows[i].getElementsByTagName("td")[2].innerText;
        if (inputDate !== "" && inputDate !== rowDate) {
          rows[i].style.display = "none";
        } else {
          rows[i].style.display = "";
          hasData = true;
        }
      }
      if (!hasData) {
        alert("No data found for the selected date.");
      }
    }

    function downloadCSV() {
      var visibleRows = Array.from(document.getElementById("milkCollectionTable").getElementsByTagName("tbody")[0].getElementsByTagName("tr")).filter(row => row.style.display !== "none");
      var csv = [];
      for (var i = 0; i < visibleRows.length; i++) {
        var row = [], cols = visibleRows[i].getElementsByTagName("td");
        for (var j = 0; j < cols.length; j++) {
          row.push(cols[j].innerText);
        }
        csv.push(row.join(","));
      }
      var csvContent = "data:text/csv;charset=utf-8," + csv.join("\n");
      var encodedUri = encodeURI(csvContent);
      var link = document.createElement("a");
      link.setAttribute("href", encodedUri);
      link.setAttribute("download", "milk_collection.csv");
      document.body.appendChild(link);
      link.click();
    }
  </script>
</body>
</html>
