<?php 
header("Cache-Control: post-check=0, pre-check=0", false);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dairy Track</title>
    <link rel="stylesheet" href="../assets/css/login.css" />
</head>
<body style="background-image: url('../assets/images/background.jpeg');">
<div class="login-container">
<h1 style="color:red;text-align:center;">Dairy Track</h1>
    <div class="login-form">
        <h2>Login</h2>
        <form action="login.php" method="POST">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="form-group">
                <!-- <button type="submit">Login</button> -->
                <input type="submit" name="login" value="login">
            </div>
        </form>
    </div>
</div>

<script src="script.js"></script>

</body>
</html>
