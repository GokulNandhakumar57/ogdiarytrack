<?php 
   include 'connect.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Society Entry Form</title>
<link rel="stylesheet" href="../assets/css/dataentry.css"/>

</head>
<body>
  <h2>Add New Society</h2>
  <form method="POST" action="Addsociety.php">
    <label for="society_id">Society ID:</label><br>
    <input type="text" id="society_id" name="society_id" required><br><br>
    
    <label for="society_name">Society Name:</label><br>
    <input type="text" id="society_name" name="society_name" required><br><br>
    
    <label for="pass">Society password:</label><br>
    <input type="password" id="pass" name="pass" required><br><br>
    
    <label for="union_id">Choose Union:</label><br>
    <select name="union_id" id="union_id" required>
      <option value="">Select Union</option>
      <!-- PHP code to fetch and display unions -->
      <?php
        // Assuming $conn is the database connection
        $sql = "SELECT * FROM unions";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        if ($result) {
          foreach($result as $row) {
            echo "<option value='" . $row['union_id'] . "'>" . $row['union_name'] . "</option>";
          }
        }
      ?>
    </select><br><br>

    <input type="submit" value="Submit">
  </form>
</body>
</html>
