<?php
session_start();
if (!isset($_SESSION['logged_in']) || $_SESSION['user_type'] !== 'admin') {
  header("Location: index.php");
  exit(); // Stop further execution of the script
}
?>
<!DOCTYPE html>
<html lang="en">
<head>

  <meta charset="utf-8">
  
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title>Dairy Track</title>

  <link rel="stylesheet" href="../assets/css/styles.min.css" />
  
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

 </head>
 

<body style='background-color:white;'>

  <div class="page-wrapper" id="main-wrapper" data-layout="vertical" data-navbarbg="skin6" data-sidebartype="full"
    data-sidebar-position="fixed" data-header-position="fixed">

    <aside class="left-sidebar">

      <div>

        <div class="brand-logo d-flex align-items-center justify-content-between">

          
          <div class="close-btn d-xl-none d-block sidebartoggler cursor-pointer" id="sidebarCollapse">

                      <i class="ti ti-x fs-8"></i>

          </div>

        </div>

        <nav class="sidebar-nav scroll-sidebar" data-simplebar="">

          <ul id="sidebarnav">

            
            <li class="sidebar-item">

              <a class="sidebar-link" href="dashboard.php" aria-expanded="false">

                <span>

                  <i class="ti ti-layout-dashboard"></i>

                </span>

                <span class="hide-menu">Dashboard</span>

              </a>

            </li>

            
            <li class="sidebar-item">

              <a class="sidebar-link" href="milkcollect.php" aria-expanded="false">

                <span>

                  <i class="ti ti-article"></i>

                </span>

                <span class="hide-menu">Milk Collections</span>

              </a>

            </li>

            <li class="sidebar-item">

              <a class="sidebar-link" href="Alert.php" aria-expanded="false">

                <span>

                  <i class="ti ti-alert-circle"></i>

                </span>

                <span class="hide-menu">Alerts</span>

              </a>

            </li>

            <li class="sidebar-item">

              <a class="sidebar-link" href="Societies.php" aria-expanded="false">

                <span>

                  <i class="ti ti-cards"></i>

                </span>

                <span class="hide-menu">Societies</span>

              </a>

            </li>

            <li class="sidebar-item">

              <a class="sidebar-link" href="Providers.php" aria-expanded="false">

                <span>

                  <i class="ti ti-file-description"></i>

                </span>

                <span class="hide-menu">Providers</span>

              </a>

            </li>

            <li class="sidebar-item">
            <a class="sidebar-link" href="#" onclick="toggleSubOptions()">
                <span>
                    <i class="ti ti-settings"></i>
                </span>
                <span class="hide-menu">Manage</span>
                <span class="sidebar-arrow"></span>
            </a>
            <ul id="manage-sub-options" aria-expanded="false" class="collapse first-level">
                <li class="sidebar-item">
                    <a class="sidebar-link" href="Unionmanage.php">
                        <span class="hide-menu">Union</span>
                        <span class="sidebar-arrow"></span>
                    </a>
                </li>
                <li class="sidebar-item">
                    <a class="sidebar-link" href="Societymanage.php">
                        <span class="hide-menu">Society</span>
                        <span class="sidebar-arrow"></span>
                    </a>
                </li>
                <li class="sidebar-item">
                    <a class="sidebar-link" href="Providermanage.php">
                        <span class="hide-menu">Providers</span>
                        <span class="sidebar-arrow"></span>
                    </a>
                </li>
            </ul>
            <li class="sidebar-item">
    <a class="sidebar-link" href="dailyreport.php">
        <span>
            <i class="ti ti-file"></i>
        </span>
        <span class="hide-menu">Everyday Report</span>
    </a>
</li>
        </li>
    </ul>

    <script>
        function toggleSubOptions() {
            var subOptions = document.getElementById("manage-sub-options");
            if (subOptions.getAttribute("aria-expanded") === "false") {
                subOptions.setAttribute("aria-expanded", "true");
            } else {
                subOptions.setAttribute("aria-expanded", "false");
            }
        }
    </script>
          </ul>
          

        </nav>

      </div>

    </aside>

    <div class="body-wrapper">

      <header class="app-header">

        <nav class="navbar navbar-expand-lg navbar-light">

          <h1>Diary Track</h1>

          <div class="navbar-collapse justify-content-end px-0" id="navbarNav">
            <ul class="navbar-nav flex-row ms-auto align-items-center justify-content-end">

              <a href="logout.php" class="btn btn-outline-primary mx-3 mt-2 d-block">Logout</a>

            </ul>

          </div>

        </nav>

      </header>

      <div class="container-fluid" style='background-color:white;'>

        <div class="row">

          <div class="col-lg-8 d-flex align-items-strech">

            <div class="card w-100">

              <div class="card-body" style='background-color:white;'>

                <div class="d-sm-flex d-block align-items-center justify-content-between mb-9">

                  <div class="mb-3 mb-sm-0">

                    <h5 class="card-title fw-semibold">Collection Overview</h5>

                  </div>

                </div>

                <?php
include 'connect.php';

if (!$conn) {
    echo "Error: Connection to database failed!";
    exit;
}
$startOfWeek = date('Y-m-d', strtotime('last Sunday'));
$endOfWeek = date('Y-m-d', strtotime('next Saturday'));
$startOfMonth = date('Y-m-01');
$endOfMonth = date('Y-m-t');

$query1= "SELECT collection_date, SUM(quantity) AS total_collected
            FROM milkcollection 
            WHERE collection_date BETWEEN '$startOfWeek' AND '$endOfWeek'
            GROUP BY collection_date";
$stmt1= $conn->query($query1);

if (!$stmt1) {
    echo "Error: Query execution failed!";
    exit;
}
$data = $stmt1->fetchAll(PDO::FETCH_ASSOC);

if ($data) {
    $dates = array();
    $total_collected = array();
    foreach ($data as $row) {
        $dates[] = $row['collection_date'];
        $total_collected[] = $row['total_collected'];
    }
} else {

    echo "No milk collection data found for the current week.";
    exit;
}
$query2= "SELECT SUM(quantity) AS total_collected FROM milkcollection WHERE collection_date BETWEEN '$startOfMonth' AND '$endOfMonth'";

$stmt2= $conn->query($query2);

if (!$stmt2) {
    echo "Error: Query execution failed!";
    exit;
}
$totalCollectedRow = $stmt2->fetch(PDO::FETCH_ASSOC);
$totalCollected = $totalCollectedRow['total_collected'];
$queryUnion = "SELECT u.union_name, SUM(mc.quantity) AS total_collected
            FROM milkcollection mc
            INNER JOIN societies s ON mc.society_id = s.society_id
            INNER JOIN unions u ON s.union_id = u.union_id
            GROUP BY u.union_id";
$stmtUnion = $conn->query($queryUnion);
if (!$stmtUnion) {
  echo "Error: Query execution failed!";
  exit;
}

$unionData = $stmtUnion->fetchAll(PDO::FETCH_ASSOC);

$queryHighestCollection = $queryHighestCollection = "SELECT mc.collection_id, mc.society_id, mc.provider_id, mc.quantity
FROM milkcollection mc
WHERE mc.collection_date = CURDATE()
ORDER BY mc.quantity DESC
LIMIT 5";   
$stmtHighestCollection = $conn->query($queryHighestCollection);

if (!$stmtHighestCollection) {
    echo "Error: Query execution failed!";
    exit;
}

$highestCollectionData = $stmtHighestCollection->fetchAll(PDO::FETCH_ASSOC);
$conn = null;
?>


<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
<script>
    $(function () {
        var milkCollectionChart = {
            series: [{
                name: "Total Collected",
                data: <?php echo json_encode($total_collected); ?>,
            }],
            chart: {
                type: "bar",
                height: 345,
                offsetX: -15,
                toolbar: { show: true },
                foreColor: "#adb0bb",
                fontFamily: 'inherit',
                sparkline: { enabled: false },
            },
            colors: ["#5D87FF"],
            plotOptions: {
                bar: {
                    horizontal: false,
                    columnWidth: "8%",
                    borderRadius: [6],
                    borderRadiusApplication: 'end',
                    borderRadiusWhenStacked: 'all'
                },
            },
            markers: { size: 0 },
            dataLabels: {
                enabled: false,
            },
            legend: {
                show: false,
            },
            grid: {
                borderColor: "rgba(0,0,0,0.1)",
                strokeDashArray: 3,
                xaxis: {
                    lines: {
                        show: false,
                    },
                },
            },
            xaxis: {
                type: "category",
                categories: <?php echo json_encode($dates); ?>,
                labels: {
                    style: { cssClass: "grey--text lighten-2--text fill-color" },
                },
            },
            yaxis: {
                show: true,
                min: 0,
                tickAmount: 4,
                labels: {
                    style: {
                        cssClass: "grey--text lighten-2--text fill-color",
                    },
                },
            },
            stroke: {
                show: true,
                width: 3,
                lineCap: "butt",
                colors: ["transparent"],
            },
            tooltip: { theme: "light" },
            responsive: [
                {
                    breakpoint: 600,
                    options: {
                        plotOptions: {
                            bar: {
                                borderRadius: 3,
                            }
                        },
                    }
                }
            ]
        };

        var milkCollectionChart = new ApexCharts(document.querySelector("#milkCollectionChart"), milkCollectionChart);
        milkCollectionChart.render();
    });
</script>

<div id="milkCollectionChart"></div>
                
                
              </div>

            </div>

          </div>

          <div class="col-lg-4">

            <div class="row">

              <div class="col-lg-12">

              

                <div class="card">

                  <div class="card-body" style='background-color:white;'>

                    <div class="row alig n-items-start">

                      <div class="col-8">

                        <h5 class="card-title mb-9 fw-semibold"> Monthly Collections </h5>

                        <h4 class="fw-semibold mb-3"><?php echo number_format($totalCollected, 2); ?> ltr</h4>

  </div>

                    </div>

                  </div>

                  <div id="earning"></div>

                </div>

              </div>

            </div>

          </div>

        </div>

        <div class="row" style='background-color:white;'>

          <div class="col-lg-4 d-flex align-items-stretch">

            <div class="card w-100" style='background-color:white;'>

              <div class="card-body p-4">

                <div class="mb-4">

                  <h5 class="card-title fw-semibold">Union Collection</h5>

                </div>

                <ul class="timeline-widget mb-0 position-relative mb-n5">

                <?php
                // Loop through the union data and display union names and total collections
                foreach ($unionData as $union) {
                ?>
 
                 <li class="timeline-item d-flex position-relative overflow-hidden">

                    <div class="timeline-time text-dark flex-shrink-0 text-end"><?php echo $union['union_name']; ?></div>

                    <div class="timeline-badge-wrap d-flex flex-column align-items-center">

                      <span class="timeline-badge border-2 border border-primary flex-shrink-0 my-8"></span>

                      <span class="timeline-badge-border d-block flex-shrink-0"></span>

                    </div>

                    <div class="timeline-desc fs-3 text-dark mt-n1"><?php echo $union['total_collected']; ?> </div>

                  </li>
                  <?php
                }
                ?>
                </ul>

              </div>

            </div>

          </div>

          <div class="col-lg-8 d-flex align-items-stretch">

            <div class="card w-100" style='background-color:white;'>

              <div class="card-body p-4">

                <h5 class="card-title fw-semibold mb-4">Highest Collection</h5>

                <div class="table-responsive">

                  <table class="table text-nowrap mb-0 align-middle">

                    <thead class="text-dark fs-4">

                      <tr>

                        <th class="border-bottom-0">

                          <h6 class="fw-semibold mb-0">Collection ID</h6>

                        </th>

                        <th class="border-bottom-0">

                          <h6 class="fw-semibold mb-0">Society ID</h6>

                        </th>

                        <th class="border-bottom-0">

                          <h6 class="fw-semibold mb-0">Provider ID</h6>

                        </th>

                        <th class="border-bottom-0">

                          <h6 class="fw-semibold mb-0">Quantity</h6>

                        </th>

                      </tr>

                    </thead>

                    <tbody>
                    <?php foreach ($highestCollectionData as $row) { ?>
                      <tr>

                        <td class="border-bottom-0">

                            <h6 class="fw-semibold mb-1"><?php echo $row['collection_id']; ?></h6>
                         </td>

                        <td class="border-bottom-0">

                          <p class="mb-0 fw-normal"><?php echo $row['society_id']; ?></p>

                        </td>

                        <td class="border-bottom-0">

                          <div class="d-flex align-items-center gap-2">

                            <span class="badge bg-primary rounded-3 fw-semibold"><?php echo $row['provider_id']; ?></span>

                          </div>

                        </td>

                        <td class="border-bottom-0">

                          <h6 class="fw-semibold mb-0 fs-4"><?php echo $row['quantity']; ?> ltr</h6>

                        </td>

                      </tr>
                      <?php } ?>
                      
                  </tbody>
  
                  </table>

                </div>

              </div>

            </div>

          </div>

        </div>

        
      </div>

    </div>

  </div>

  <script src="../assets/libs/jquery/dist/jquery.min.js"></script>

  <script src="../assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>

  <script src="../assets/js/sidebarmenu.js"></script>

  <script src="../assets/js/app.min.js"></script>

  <script src="../assets/libs/apexcharts/dist/apexcharts.min.js"></script>

  <script src="../assets/libs/simplebar/dist/simplebar.js"></script>

  
  

</body>


</html>