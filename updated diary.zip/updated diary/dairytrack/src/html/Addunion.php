<?php
// Include the database connection file
include 'connect.php';

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $union_id = $_POST['union_id'];
    $union_name = $_POST['union_name'];
    $district_id = $_POST['district_id'];
    $sql1="SELECT * FROM unions WHERE union_id=:union_id";
    $stmt1 = $conn->prepare($sql1);
    $stmt1->bindParam(':union_id', $union_id);
    $stmt1->execute();
    $row = $stmt1->fetch(PDO::FETCH_ASSOC);
    if ($stmt1->rowCount() > 0){
        echo "<script> alert('UserId already in use...')</script>";
        echo "<script>window.location.href ='Unionmanage.php'</script>";
        exit();
    }
    else{
    // Prepare and execute SQL statement to insert data into the database
    $sql = "INSERT INTO unions (union_id, union_name, district_id) VALUES (:union_id, :union_name, :district_id)";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':union_id', $union_id);
    $stmt->bindParam(':union_name', $union_name);
    $stmt->bindParam(':district_id', $district_id);

    // Execute the statement
    if ($stmt->execute()) {
        echo "<script> alert('Union added successfully.')</script>";
        echo "<script>window.location.href ='Unionmanage.php'</script>";
        exit();
    } else {
        echo "<script> alert('Error: Unable to add union.')</script>";
        echo "<script>window.location.href ='Unionmanage.php'</script>";
        exit();
    }
}
}
?>
