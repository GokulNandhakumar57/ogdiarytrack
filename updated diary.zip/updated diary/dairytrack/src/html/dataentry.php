<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Milk Entry Form</title>
    <link rel="stylesheet" href="../assets/css/dataentry.css"/>
</head>
<body>
    <h2>Data Entry Form</h2>
    <form method="POST" action="datastore.php">
        <label for="shift">Choose a Shift:</label>
        <select name="shift" id="shift" required>
            <option value="morning">Morning</option>
            <option value="evening">Evening</option>
        </select><br><br>
        <label for="provider_id">Provider ID:</label><br>
        <input type="text" id="provider_id" name="provider_id" required><br><br>

        <label for="snf_value">SNF Value:</label><br>
        <input type="text" id="snf_value" name="snf_value" required><br><br>

        <label for="fat">Fat:</label><br>
        <input type="text" id="fat" name="fat" required><br><br>

        <label for="quantity">Quantity:</label><br>
        <input type="text" id="quantity" name="quantity" required><br><br>

        <input type="submit" value="Submit">
    </form>

    <!-- Logout Button -->
    <form action="logout.php" method="post">
        <input type="submit" value="Logout">
    </form>
</body>
</html>
