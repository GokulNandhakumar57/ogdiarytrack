<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Dairy Track - Alerts</title>
  <link rel="stylesheet" href="../assets/css/styles.min.css" />
</head>
<body>
  <div class="page-wrapper" id="main-wrapper" data-layout="vertical" data-navbarbg="skin6" data-sidebartype="full"
    data-sidebar-position="fixed" data-header-position="fixed">
    <div class="body-wrapper">
      <div class="container-fluid">
        <h1>Alerts</h1>
        <div class="row">
          <div class="col-md-12">
            <div class="alert alert-danger" role="alert" id="alert-container"></div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <h3>Unusual Data Details</h3>
            <table class="table table-striped table-bordered">
              <thead>
                <tr>
                  <th>Society ID</th>
                  <th>Society Name</th>
                  <th>Collection Date</th>
                  <th>Collected Quantity</th>
                  <th>Shift</th>
                  <th>Threshold</th>
                  <th>Difference</th>
                </tr>
              </thead>
              <tbody id="data-table">
                <?php
                  // Include database connection details (replace with your actual credentials)
                 
                  // Define yesterday as a global variable
                  $today = date("Y-m-d");
                  $yesterday = date("Y-m-d", strtotime("-1 day"));


                  // Initialize array to store alert messages
                  $alerts;

                  // Initialize array to store details for unusual data
                  $details = array();

                  // Define thresholds (you can adjust these values as needed)
                  $collection_increase_threshold = 0.20; // 20% increase compared to average
                  $collection_decrease_threshold = 0.30; // 30% decrease compared to average
                  $fat_content_threshold_min = 3.0; // Minimum fat content threshold
                  $fat_content_threshold_max = 5.0; // Maximum fat content threshold
                  $snf_threshold_min = 3.0; // SNF threshold Min
                  $snf_threshold_max = 6.0;// SNF threshold Max

                  try {
                      // Create a PDO connection
                      // Use your actual database connection details here
                      include('connect.php');

                      // Function to calculate average collection for a society
                      function getAverageCollection($societyId, $conn)
                      {
                          $sql1 = "SELECT AVG(quantity) AS average_collection
                                  FROM milkcollection
                                  WHERE society_id = :societyId";
                          $stmt1 = $conn->prepare($sql1);
                          $stmt1->bindParam(':societyId', $societyId, PDO::PARAM_INT);
                          $stmt1->execute();
                          $row1 = $stmt1->fetch(PDO::FETCH_ASSOC);
                          return $row1['average_collection'] ?? null;
                      }

                      // Loop through societies and check for alerts
                      $sql = "SELECT milkcollection.society_id, societies.society_name, milkcollection.collection_date, milkcollection.quantity,milkcollection.shift, milkcollection.fat, milkcollection.snf, milkcollection.provider_id
        FROM milkcollection
        INNER JOIN societies ON milkcollection.society_id = societies.society_id
        WHERE milkcollection.collection_date = :today";

                      $stmt = $conn->prepare($sql);
                      //$stmt->bindParam(':yesterday', $yesterday, PDO::PARAM_STR);
                      $stmt->bindParam(':today', $today, PDO::PARAM_STR);
                      $stmt->execute();
                      
                      if ($stmt->rowCount() > 0) {
                          while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                              $societyId = $row['society_id'];
                              $societyName = $row['society_name'];
                              $collectionDate = $row['collection_date'];
                              $collectedQuantity = $row['quantity'];
                              $collectedshift = $row['shift'];
                              $fatContent = $row['fat'];
                              $snfcontent = $row['snf'];
                              
                              $averageCollection = getAverageCollection($societyId, $conn);

                              // Check for quality parameter violations
                              if ($fatContent < $fat_content_threshold_min) {
                                  $details[] = array(
                                      "society_id" => $societyId,
                                      "society_name" => $societyName,
                                      "collection_date" => $collectionDate,
                                      "collected_quantity" => $collectedQuantity,
                                      "collected_shift" => $collectedshift,
                                      "threshold" => "Fat Content (Min)",
                                      "difference" => $fatContent - $fat_content_threshold_min
                                  );
                                  $alerts ="There are some unusual data in today's entry..";
                                
                              } elseif ($fatContent > $fat_content_threshold_max) {
                                  $details[] = array(
                                      "society_id" => $societyId,
                                      "society_name" => $societyName,
                                      "collection_date" => $collectionDate,
                                      "collected_quantity" => $collectedQuantity,
                                      "collected_shift" => $collectedshift,
                                      "threshold" => "Fat Content (Max)",
                                      "difference" => $fatContent - $fat_content_threshold_max
                                  );
                                  $alerts ="There are some unusual data in today's entry..";
                              }

                              if ($snfcontent < $snf_threshold_min) {
                                  $details[] = array(
                                      "society_id" => $societyId,
                                      "society_name" => $societyName,
                                      "collection_date" => $collectionDate,
                                      "collected_quantity" => $collectedQuantity,
                                      "collected_shift" => $collectedshift,
                                      "threshold" => "SNF content(MIN)",
                                      "difference" => $snfcontent - $snf_threshold_min
                                  );
                                  $alerts ="There are some unusual data in today's entry..";
                                
                              }elseif ($snfcontent > $snf_threshold_max) {
                                $details[] = array(
                                    "society_id" => $societyId,
                                    "society_name" => $societyName,
                                    "collection_date" => $collectionDate,
                                    "collected_quantity" => $collectedQuantity,
                                    "collected_shift" => $collectedshift,
                                    "threshold" => "SNF content(MAX)",
                                    "difference" => $snfcontent - $snf_threshold_max
                                );
                                $alerts ="There are some unusual data in today's entry.."; 
                            }
                          }

                          // Output alerts and details directly into the HTML
                          if (!empty($alerts)) {
                              echo '<script>';
                              echo 'document.getElementById("alert-container").innerText = ' . json_encode($alerts) . ';';
                              echo '</script>';
                          } else {
                              echo '<script>';
                              echo 'document.getElementById("alert-container").innerText = "No unusual data detected.";';
                              echo '</script>';
                          }

                          if (!empty($details)) {
                              foreach ($details as $record) {
                                  echo '<tr>';
                                  echo '<td>' . $record['society_id'] . '</td>';
                                  echo '<td>' . $record['society_name'] . '</td>';
                                  echo '<td>' . $record['collection_date'] . '</td>';
                                  echo '<td>' . $record['collected_quantity'] . '</td>';
                                  echo '<td>' . $record['collected_shift'] . '</td>';
                                  echo '<td>' . $record['threshold'] . '</td>';
                                  echo '<td>' . $record['difference'] . '</td>';
                                  echo '</tr>';
                              }
                          }
                      } else {
                          echo '<script>';
                          echo 'document.getElementById("alert-container").innerText = "No data found.";';
                          echo '</script>';
                      }
                  } catch (PDOException $e) {
                      echo '<script>';
                      echo 'document.getElementById("alert-container").innerText = "Error: ' . $e->getMessage() . '";';
                      echo '</script>';
                  }

                  // Close connection
                  $conn = null;
                ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script src="../assets/libs/jquery/dist/jquery.min.js"></script>
  <script src="../assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
