<?php
session_start();
if (!isset($_SESSION['logged_in'])) {
    header("Location: index.php");
    exit();
}

// Include database connection details
include('connect.php');

// Get the current date
$currentDate = date('Y-m-d');

// Fetch morning shift collection data for the current date
$queryMorning = "SELECT society_id, SUM(quantity) AS total_quantity FROM milkcollection WHERE collection_date = '$currentDate' AND shift = 'morning' GROUP BY society_id";
$stmtMorning = $conn->query($queryMorning);
$morningCollections = $stmtMorning->fetchAll(PDO::FETCH_ASSOC);

// Fetch evening shift collection data for the current date
$queryEvening = "SELECT society_id, SUM(quantity) AS total_quantity FROM milkcollection WHERE collection_date = '$currentDate' AND shift = 'evening' GROUP BY society_id";
$stmtEvening = $conn->query($queryEvening);
$eveningCollections = $stmtEvening->fetchAll(PDO::FETCH_ASSOC);

// Close the database connection
$conn = null;

// Format the data into a text report
$report = "Daily Collection Report for " . $currentDate . "\n\n";

$report .= "Morning Shift:\n";
if (!empty($morningCollections)) {
    foreach ($morningCollections as $collection) {
        $report .= "Society ID: " . $collection['society_id'] . ", Total Quantity: " . $collection['total_quantity'] . " ltr\n";
    }
} else {
    $report .= "No collection data found for morning shift.\n";
}

$report .= "\nEvening Shift:\n";
if (!empty($eveningCollections)) {
    foreach ($eveningCollections as $collection) {
        $report .= "Society ID: " . $collection['society_id'] . ", Total Quantity: " . $collection['total_quantity'] . " ltr\n";
    }
} else {
    $report .= "No collection data found for evening shift.\n";
}

// Function to force download the report
function downloadReport($content) {
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="daily_collection_report.txt"');
    echo $content;
    exit();
}

// Check if the download button was clicked
if (isset($_POST['download'])) {
    downloadReport($report);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daily Collection Report</title>
    <link rel="stylesheet" href="../assets/css/dailyreport.css" />
</head>
<body>
    <h1>Daily Collection Report</h1>
    <pre><?php echo $report; ?></pre>
</html>
