<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Milk Providers</title>
  <link rel="stylesheet" href="../assets/css/styles.min.css" />
  <style>
    /* CSS styling for the table */
    body{
      padding: 20px;
    }
    table {
      width: 100%;
      border-collapse: collapse;
    }
    th, td {
      padding: 8px;
      text-align: left;
      border-bottom: 1px solid #ddd;
    }
    th {
      background-color: #f2f2f2;
    }
  </style>
</head>
<body>
  <h1 style="text-align: center;font-weight:bold;">Milk Providers</h1>
  <table>
    <thead>
      <tr>
        <th>Provider ID</th>
        <th>Name</th>
        <th>Society ID</th>
        <th>Society Name</th>
        <th>Union Name</th>
        <th>District Name</th>
        <th>Phone Number</th>
        <th>Address</th>
      </tr>
    </thead>
    <tbody>
      <?php
        // Include database connection details
        include('connect.php');

        // Fetch data from milkcollection table along with related society, union, district, and provider information
        $sql = "SELECT 
        pr.provider_id,
        pr.provider_name,
        so.society_id,
        so.society_name,
        un.union_name,
        di.district_name,
        pr.phone_no,
        pr.contact_info 
        FROM providers pr
        JOIN milkcollection mc ON pr.provider_id = mc.provider_id
        JOIN societies so ON mc.society_id = so.society_id
        JOIN unions un ON so.union_id = un.union_id
        JOIN districts di ON un.district_id = di.district_id
        GROUP BY pr.provider_id, pr.provider_name;";
        $stmt = $conn->prepare($sql);
        $stmt->execute();

        // Display data for each milk collection
        if ($stmt->rowCount() > 0) {
          while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            echo "<tr>";
            echo "<td>".$row['provider_id']."</td>";
            echo "<td>".$row['provider_name']."</td>";
            echo "<td>".$row['society_id']."</td>";
            echo "<td>".$row['society_name']."</td>";
            echo "<td>".$row['union_name']."</td>";
            echo "<td>".$row['district_name']."</td>";
            echo "<td>".$row['phone_no']."</td>";
            echo "<td>".$row['contact_info']."</td>";
            echo "</tr>";
          }
        } else {
          echo "<tr><td colspan='11'>No data found</td></tr>";
        }

        // Close connection
        $conn = null;
      ?>
    </tbody>
  </table>
</body>
</html>
