<?php
// Include the database connection file
include 'connect.php';

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $society_id = $_POST['society_id'];
    $society_name = $_POST['society_name'];
    $society_pass = $_POST['pass'];
    $union_id = $_POST['union_id'];
    $sql1="SELECT * FROM societies WHERE society_id=:society_id";
    $stmt1 = $conn->prepare($sql1);
    $stmt1->bindParam(':society_id', $society_id);
    $stmt1->execute();
    $row = $stmt1->fetch(PDO::FETCH_ASSOC);
    if ($stmt1->rowCount() > 0){
        echo "<script> alert('UserId already in use...')</script>";
        echo "<script>window.location.href ='Societymanage.php'</script>";
        exit();
    }else{
    // Prepare and execute SQL statement to insert data into the database
    $sql = "INSERT INTO societies (society_id, society_name,password, union_id) VALUES (:society_id, :society_name, :society_pass, :union_id)";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':society_id', $society_id);
    $stmt->bindParam(':society_name', $society_name);
    $stmt->bindParam(':society_pass', $society_pass);
    $stmt->bindParam(':union_id', $union_id);

    if($stmt->execute()) {
        echo "<script> alert('Society added successfully'); </script>";
        echo "<script>window.location.href ='Societymanage.php'</script>";
        exit();
    } else {
        echo "<script> alert('Failed to add society...Try again..'); </script>";
        echo "<script>window.location.href ='Societymanage.php'</script>";
        exit();
    }
}
}
?>
